package com.example.wuziqizyn


import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.wuziqizyn.api.GameRecordRequest
import com.example.wuziqizyn.api.RetrofitClient
import com.example.wuziqizyn.data.AppDatabase
import com.example.wuziqizyn.data.GameEntity
import com.example.wuziqizyn.data.MoveEntity
import com.example.wuziqizyn.utils.UserPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.awaitResponse

class MainActivity : AppCompatActivity(), GameBoardView.Listener {

    private lateinit var tvStatus: TextView
    private lateinit var board: GameBoardView
    private lateinit var btnUndo: Button
    private lateinit var btnReset: Button
    private lateinit var btnHistory: Button
    private lateinit var btnRanking: Button
    private lateinit var spMode: Spinner

    // 内存里暂存走棋（避免悔棋复杂度）
    private val moveBuffer = mutableListOf<Triple<Int,Int,Int>>() // r,c,player
    private var gameStartTime: Long = System.currentTimeMillis()

    //  DB
    private val db by lazy { AppDatabase.get(this) }
    private val gameDao by lazy { db.gameDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        board = findViewById(R.id.boardView)
        btnUndo = findViewById(R.id.btnUndo)
        btnReset = findViewById(R.id.btnReset)
        btnHistory = findViewById(R.id.btnHistory)
        btnRanking = findViewById(R.id.btnRanking)
        spMode = findViewById(R.id.spMode)

        board.listener = this

        val modes = listOf("本地双人","人机（我先手）","人机（AI先手）")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        spMode.adapter = adapter
        spMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                board.mode = when (pos) {
                    0 -> GameBoardView.Mode.LOCAL_TWO_PLAYERS
                    1 -> GameBoardView.Mode.HUMAN_FIRST_AI
                    else -> GameBoardView.Mode.AI_FIRST_HUMAN
                }
                tvStatus.text = statusText(1) + "（" + modes[pos] + "）"
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        btnUndo.setOnClickListener {
            it.isEnabled = false
            board.undo()
            it.postDelayed({ it.isEnabled = true }, 150)
        }
        btnReset.setOnClickListener {
            board.reset() // onReset() 回调里会清空 moveBuffer & 重置时间
        }
        btnRanking.setOnClickListener {
            startActivity(Intent(this, RankingActivity::class.java))
        }
        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        tvStatus.text = statusText(1) + "（本地双人）"
        gameStartTime = System.currentTimeMillis()
    }

    private fun statusText(player: Int): String {
        val who = if (player == 1) "黑棋" else "白棋"
        return "${who}走"
    }

    // ========== GameBoardView.Listener 实现 ==========
    override fun onTurnChanged(player: Int) {
        val modeText = spMode.selectedItem.toString()
        tvStatus.text = statusText(player) + "（$modeText）"
    }

    override fun onWin(winner: Int) {
        val who = if (winner == 1) "黑棋" else "白棋"
        val modeText = spMode.selectedItem.toString()
        tvStatus.text = "$who 胜利（$modeText）"

        val isPvpMode = modeText.contains("本地双人")

        if (isPvpMode) {
            if (!UserPreferences.hasPvpNicknames(this)) {
                showPvpNicknameDialogOnWin(winner)
            } else {
                Toast.makeText(this, "$who 胜利！已保存对局。", Toast.LENGTH_SHORT).show()
                saveGameToDatabase(winner)
            }
        } else {
            if (!UserPreferences.hasNickname(this)) {
                showNicknameDialogOnWin(winner)
            } else {
                Toast.makeText(this, "$who 胜利！已保存对局。", Toast.LENGTH_SHORT).show()
                saveGameToDatabase(winner)
            }
        }
    }

    private fun showPvpNicknameDialogOnWin(winner: Int) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_set_pvp_nicknames, null)
        val tvTitle = dialogView.findViewById<TextView>(R.id.tvTitle)
        val etBlackNickname = dialogView.findViewById<EditText>(R.id.etBlackNickname)
        val etWhiteNickname = dialogView.findViewById<EditText>(R.id.etWhiteNickname)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)
        val btnConfirm = dialogView.findViewById<Button>(R.id.btnConfirm)

        tvTitle.text = "请设置玩家昵称"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        btnConfirm.setOnClickListener {
            val blackNickname = etBlackNickname.text.toString().trim()
            val whiteNickname = etWhiteNickname.text.toString().trim()

            if (blackNickname.isEmpty()) {
                Toast.makeText(this, "黑棋玩家昵称不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (blackNickname.length !in 2..10) {
                Toast.makeText(this, "黑棋玩家昵称需2-10个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (whiteNickname.isEmpty()) {
                Toast.makeText(this, "白棋玩家昵称不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (whiteNickname.length !in 2..10) {
                Toast.makeText(this, "白棋玩家昵称需2-10个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val success = UserPreferences.setPvpNicknames(this, blackNickname, whiteNickname)
            if (success) {
                val who = if (winner == 1) "黑棋" else "白棋"
                Toast.makeText(this, "$who 胜利！已保存对局。", Toast.LENGTH_SHORT).show()
                saveGameToDatabase(winner)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "设置失败,请重试", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
        etBlackNickname.requestFocus()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    private fun showNicknameDialogOnWin(winner: Int) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_set_nickname, null)
        val tvTitle = dialogView.findViewById<TextView>(R.id.tvTitle)
        val etNickname = dialogView.findViewById<EditText>(R.id.etNickname)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)
        val btnConfirm = dialogView.findViewById<Button>(R.id.btnConfirm)

        tvTitle.text = "请设置昵称"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)  // 禁止点击外部关闭
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        btnCancel.setOnClickListener {
            saveGameToDatabase(winner)
            dialog.dismiss()
        }

        btnConfirm.setOnClickListener {
            val nickname = etNickname.text.toString().trim()
            if (nickname.isEmpty()) {
                Toast.makeText(this, "昵称不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (nickname.length < 2) {
                Toast.makeText(this, "昵称至少2个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (nickname.length > 10) {
                Toast.makeText(this, "昵称最多10个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val success = UserPreferences.setNickname(this, nickname)
            if (success) {
                val who = if (winner == 1) "黑棋" else "白棋"
                Toast.makeText(this, "$who 胜利！已保存对局。", Toast.LENGTH_SHORT).show()
                saveGameToDatabase(winner)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "设置失败,请重试", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
        etNickname.requestFocus()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    private fun saveGameToDatabase(winner: Int) {
        val end = System.currentTimeMillis()
        val resultLabel = if (winner == 1) "BLACK_WIN" else "WHITE_WIN"
        val steps = moveBuffer.size
        val firstPlayer = 1
        val boardSize = 15
        val modeLabel = spMode.selectedItem.toString()
        val nickname = UserPreferences.getNickname(this)

        val snapshot = moveBuffer.toList()
        lifecycleScope.launch(Dispatchers.IO) {
            val gameId = gameDao.insertGame(
                GameEntity(
                    startedAt = gameStartTime,
                    endedAt = end,
                    result = resultLabel,
                    firstPlayer = firstPlayer,
                    boardSize = boardSize,
                    steps = steps,
                    modeLabel = modeLabel,
                    nickname = nickname
                )
            )
            val entities = snapshot.mapIndexed { idx, t ->
                MoveEntity(
                    gameId = gameId,
                    seq = idx,
                    r = t.first, c = t.second, player = t.third
                )
            }
            gameDao.insertMoves(entities)

            val isPvpMode = modeLabel.contains("本地双人")
            if (isPvpMode) {
                val blackNickname = UserPreferences.getBlackNickname(this@MainActivity)
                val whiteNickname = UserPreferences.getWhiteNickname(this@MainActivity)
                if (!blackNickname.isNullOrEmpty() && !whiteNickname.isNullOrEmpty()) {
                    reportPvpGameResult(winner, blackNickname, whiteNickname)
                }
            } else {
                if (!nickname.isNullOrEmpty()) {
                    reportAiGameResult(winner, modeLabel, nickname)
                }
            }
        }
    }

    private suspend fun reportAiGameResult(winner: Int, modeLabel: String, playerName: String) {
        try {
            val (playerPieceType, playerResult) = when {
                modeLabel.contains("我先手") -> {
                    val result = if (winner == 1) 1 else 2
                    Pair(1, result)
                }
                modeLabel.contains("AI先手") -> {
                    val result = if (winner == 2) 1 else 2
                    Pair(2, result)
                }
                else -> Pair(1, 1)
            }

            val request = GameRecordRequest(
                gameType = 1,
                playerName = playerName,
                pieceType = playerPieceType,
                gameResult = playerResult
            )
            val response = RetrofitClient.apiService.recordGame(request).awaitResponse()

            if (!response.isSuccessful || response.body()?.code != 200) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "排行榜数据上报失败", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, "网络错误: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun reportPvpGameResult(winner: Int, blackNickname: String, whiteNickname: String) {
        try {
            val winnerNickname = if (winner == 1) blackNickname else whiteNickname
            val winnerPieceType = if (winner == 1) 1 else 2

            val winnerRequest = GameRecordRequest(
                gameType = 2,
                playerName = winnerNickname,
                pieceType = winnerPieceType,
                gameResult = 1
            )
            RetrofitClient.apiService.recordGame(winnerRequest).awaitResponse()

            val loserNickname = if (winner == 1) whiteNickname else blackNickname
            val loserPieceType = if (winner == 1) 2 else 1

            val loserRequest = GameRecordRequest(
                gameType = 2,
                playerName = loserNickname,
                pieceType = loserPieceType,
                gameResult = 2
            )
            val response = RetrofitClient.apiService.recordGame(loserRequest).awaitResponse()

            if (!response.isSuccessful || response.body()?.code != 200) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "排行榜数据上报失败", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, "网络错误: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onModeInfo(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    override fun onMovePlaced(r: Int, c: Int, player: Int, seq: Int) {
        if (seq == 0) gameStartTime = System.currentTimeMillis()
        if (seq < moveBuffer.size) {
            moveBuffer.subList(seq, moveBuffer.size).clear()
        }
        moveBuffer.add(Triple(r, c, player))
    }

    override fun onUndo(r: Int, c: Int, player: Int, newSeq: Int) {
        if (newSeq >= 0 && newSeq < moveBuffer.size) {
            moveBuffer.subList(newSeq, moveBuffer.size).clear()
        }
    }

    override fun onReset() {
        moveBuffer.clear()
        gameStartTime = System.currentTimeMillis()
    }
}
