package com.example.wuziqizyn.api

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    @SerializedName("code") val code: Int,
    @SerializedName("msg") val msg: String,
    @SerializedName("data") val data: T?
)

data class GameRecordRequest(
    @SerializedName("gameType") val gameType: Int,
    @SerializedName("playerName") val playerName: String,
    @SerializedName("pieceType") val pieceType: Int,
    @SerializedName("gameResult") val gameResult: Int
)

data class RankingItem(
    @SerializedName("rank") val rank: Int,
    @SerializedName("playerName") val playerName: String,
    @SerializedName("pieceType") val pieceType: Int,
    @SerializedName("winCount") val winCount: Int,
    @SerializedName("loseCount") val loseCount: Int,
    @SerializedName("totalCount") val totalCount: Int,
    @SerializedName("winRate") val winRate: Double
)
