package com.example.wuziqizyn.api

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {
    @POST("/api/game/recordGame")
    fun recordGame(@Body request: GameRecordRequest): Call<ApiResponse<Any>>

    @GET("/api/game/ranking")
    fun getRanking(
        @Query("gameType") gameType: Int,
        @Query("pieceType") pieceType: Int
    ): Call<ApiResponse<List<RankingItem>>>
}
