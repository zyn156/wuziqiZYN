package com.example.wuziqizyn

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * 排行榜 RecyclerView 适配器
 */
class RankingAdapter(private var rankList: List<RankItem>) :
    RecyclerView.Adapter<RankingAdapter.RankViewHolder>() {

    /**
     * 排行项数据结构
     */
    data class RankItem(
        val rank: Int,           // 排名
        val nickname: String,    // 昵称
        val wins: Int,           // 胜场
        val totalGames: Int,     // 总局数
        val winRate: Double      // 胜率
    )

    inner class RankViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvRank: TextView = view.findViewById(R.id.tvRank)
        val tvNickname: TextView = view.findViewById(R.id.tvNickname)
        val tvWins: TextView = view.findViewById(R.id.tvWins)
        val tvWinRate: TextView = view.findViewById(R.id.tvWinRate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RankViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_ranking, parent, false)
        return RankViewHolder(view)
    }

    override fun onBindViewHolder(holder: RankViewHolder, position: Int) {
        val item = rankList[position]
        val context = holder.itemView.context

        // 排名圆圈 - 前三名特殊颜色
        holder.tvRank.text = "${item.rank}"
        when (item.rank) {
            1 -> holder.tvRank.setBackgroundResource(R.drawable.bg_rank_gold)
            2 -> holder.tvRank.setBackgroundResource(R.drawable.bg_rank_silver)
            3 -> holder.tvRank.setBackgroundResource(R.drawable.bg_rank_bronze)
            else -> holder.tvRank.setBackgroundResource(R.drawable.bg_rank_simple)
        }

        // 基本信息
        holder.tvNickname.text = item.nickname
        holder.tvWins.text = "${item.wins}胜"

        // 胜率 - 整数显示更简洁
        val winRateInt = item.winRate.toInt()
        holder.tvWinRate.text = "$winRateInt%"
    }

    override fun getItemCount() = rankList.size

    /**
     * 更新数据
     */
    fun updateData(newList: List<RankItem>) {
        rankList = newList
        notifyDataSetChanged()
    }
}
