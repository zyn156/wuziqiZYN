package com.example.wuziqizyn

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.wuziqizyn.api.RetrofitClient
import com.example.wuziqizyn.utils.UserPreferences
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.awaitResponse

class RankingActivity : AppCompatActivity() {

    private lateinit var tvCurrentNickname: TextView
    private lateinit var tvPvpNicknames: TextView
    private lateinit var btnSetNickname: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var chipGroupMode: ChipGroup
    private lateinit var chipGroupColor: ChipGroup
    private lateinit var chipModeAI: Chip
    private lateinit var chipModePVP: Chip
    private lateinit var chipColorBlack: Chip
    private lateinit var chipColorWhite: Chip

    private lateinit var adapter: RankingAdapter

    // 当前筛选条件
    private var currentMode = RankMode.AI      // 人机/双人
    private var currentColor = RankColor.BLACK // 黑/白

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ranking)

        tvCurrentNickname = findViewById(R.id.tvCurrentNickname)
        tvPvpNicknames = findViewById(R.id.tvPvpNicknames)
        btnSetNickname = findViewById(R.id.btnSetNickname)
        recyclerView = findViewById(R.id.recyclerView)
        chipGroupMode = findViewById(R.id.chipGroupMode)
        chipGroupColor = findViewById(R.id.chipGroupColor)
        chipModeAI = findViewById(R.id.chipModeAI)
        chipModePVP = findViewById(R.id.chipModePVP)
        chipColorBlack = findViewById(R.id.chipColorBlack)
        chipColorWhite = findViewById(R.id.chipColorWhite)

        // 初始化RecyclerView
        adapter = RankingAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // 显示当前昵称
        refreshNickname()

        // 设置昵称按钮
        btnSetNickname.setOnClickListener {
            showNicknameDialog()
        }

        // 筛选器监听
        chipGroupMode.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                currentMode = when (checkedIds[0]) {
                    R.id.chipModeAI -> RankMode.AI
                    R.id.chipModePVP -> RankMode.PVP
                    else -> RankMode.AI
                }
                loadRankingData()
            }
        }

        chipGroupColor.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                currentColor = when (checkedIds[0]) {
                    R.id.chipColorBlack -> RankColor.BLACK
                    R.id.chipColorWhite -> RankColor.WHITE
                    else -> RankColor.BLACK
                }
                loadRankingData()
            }
        }

        // 初始加载数据
        loadRankingData()
    }

    private fun refreshNickname() {
        val nickname = UserPreferences.getNickname(this)
        tvCurrentNickname.text = nickname ?: "未设置"

        val blackNickname = UserPreferences.getBlackNickname(this)
        val whiteNickname = UserPreferences.getWhiteNickname(this)
        tvPvpNicknames.text = if (!blackNickname.isNullOrEmpty() && !whiteNickname.isNullOrEmpty()) {
            "$blackNickname vs $whiteNickname"
        } else {
            "未设置"
        }
    }

    private fun showNicknameDialog() {
        if (currentMode == RankMode.PVP) {
            showPvpNicknameDialog()
        } else {
            showAiNicknameDialog()
        }
    }

    private fun showAiNicknameDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_set_nickname, null)
        val etNickname = dialogView.findViewById<EditText>(R.id.etNickname)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)
        val btnConfirm = dialogView.findViewById<Button>(R.id.btnConfirm)

        val currentNickname = UserPreferences.getNickname(this)
        if (!currentNickname.isNullOrEmpty()) {
            etNickname.setText(currentNickname)
            etNickname.setSelection(currentNickname.length)
        }

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        btnConfirm.setOnClickListener {
            val nickname = etNickname.text.toString().trim()
            if (nickname.isEmpty()) {
                Toast.makeText(this, "昵称不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (nickname.length < 2) {
                Toast.makeText(this, "昵称至少2个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (nickname.length > 10) {
                Toast.makeText(this, "昵称最多10个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val success = UserPreferences.setNickname(this, nickname)
            if (success) {
                Toast.makeText(this, "昵称设置成功", Toast.LENGTH_SHORT).show()
                refreshNickname()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "设置失败,请重试", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()

        etNickname.requestFocus()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    private fun showPvpNicknameDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_set_pvp_nicknames, null)
        val etBlackNickname = dialogView.findViewById<EditText>(R.id.etBlackNickname)
        val etWhiteNickname = dialogView.findViewById<EditText>(R.id.etWhiteNickname)
        val btnCancel = dialogView.findViewById<Button>(R.id.btnCancel)
        val btnConfirm = dialogView.findViewById<Button>(R.id.btnConfirm)

        val currentBlack = UserPreferences.getBlackNickname(this)
        val currentWhite = UserPreferences.getWhiteNickname(this)
        if (!currentBlack.isNullOrEmpty()) {
            etBlackNickname.setText(currentBlack)
        }
        if (!currentWhite.isNullOrEmpty()) {
            etWhiteNickname.setText(currentWhite)
        }

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        btnConfirm.setOnClickListener {
            val blackNickname = etBlackNickname.text.toString().trim()
            val whiteNickname = etWhiteNickname.text.toString().trim()

            if (blackNickname.isEmpty()) {
                Toast.makeText(this, "黑棋玩家昵称不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (blackNickname.length !in 2..10) {
                Toast.makeText(this, "黑棋玩家昵称需2-10个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (whiteNickname.isEmpty()) {
                Toast.makeText(this, "白棋玩家昵称不能为空", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (whiteNickname.length !in 2..10) {
                Toast.makeText(this, "白棋玩家昵称需2-10个字符", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val success = UserPreferences.setPvpNicknames(this, blackNickname, whiteNickname)
            if (success) {
                Toast.makeText(this, "双人昵称设置成功", Toast.LENGTH_SHORT).show()
                refreshNickname()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "设置失败,请重试", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
        etBlackNickname.requestFocus()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    private fun loadRankingData() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val gameType = when (currentMode) {
                    RankMode.AI -> 1
                    RankMode.PVP -> 2
                }
                val pieceType = when (currentColor) {
                    RankColor.BLACK -> 1
                    RankColor.WHITE -> 2
                }

                val response = RetrofitClient.apiService.getRanking(gameType, pieceType).awaitResponse()

                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        val apiResponse = response.body()
                        if (apiResponse?.code == 200) {
                            val rankings = apiResponse.data ?: emptyList()

                            val adapterList = rankings.map { item ->
                                RankingAdapter.RankItem(
                                    rank = item.rank,
                                    nickname = item.playerName,
                                    wins = item.winCount,
                                    totalGames = item.totalCount,
                                    winRate = item.winRate
                                )
                            }
                            adapter.updateData(adapterList)
                        } else {
                            Toast.makeText(this@RankingActivity,
                                "获取排行榜失败: ${apiResponse?.msg}",
                                Toast.LENGTH_SHORT).show()
                            adapter.updateData(emptyList())
                        }
                    } else {
                        Toast.makeText(this@RankingActivity,
                            "服务器错误: ${response.code()}",
                            Toast.LENGTH_SHORT).show()
                        adapter.updateData(emptyList())
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@RankingActivity,
                        "网络错误: ${e.message}",
                        Toast.LENGTH_SHORT).show()
                    adapter.updateData(emptyList())
                }
            }
        }
    }

    private enum class RankMode {
        AI, PVP
    }

    private enum class RankColor {
        BLACK, WHITE
    }
}
