package com.example.wuziqizyn.utils

import android.content.Context
import android.content.SharedPreferences

// 用户偏好管理
object UserPreferences {

    private const val PREFS_NAME = "gomoku_user_prefs"
    private const val KEY_NICKNAME = "user_nickname"
    private const val KEY_BLACK_NICKNAME = "black_player_nickname"
    private const val KEY_WHITE_NICKNAME = "white_player_nickname"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // 人机对战昵称
    fun getNickname(context: Context): String? {
        return getPrefs(context).getString(KEY_NICKNAME, null)
    }

    fun setNickname(context: Context, nickname: String): Boolean {
        if (nickname.isBlank() || nickname.length !in 2..10) {
            return false
        }
        return getPrefs(context).edit()
            .putString(KEY_NICKNAME, nickname.trim())
            .commit()
    }

    fun hasNickname(context: Context): Boolean {
        return !getNickname(context).isNullOrEmpty()
    }

    fun clearNickname(context: Context) {
        getPrefs(context).edit().remove(KEY_NICKNAME).apply()
    }

    // 双人对战昵称
    fun getBlackNickname(context: Context): String? {
        return getPrefs(context).getString(KEY_BLACK_NICKNAME, null)
    }

    fun getWhiteNickname(context: Context): String? {
        return getPrefs(context).getString(KEY_WHITE_NICKNAME, null)
    }

    fun setPvpNicknames(context: Context, blackNickname: String, whiteNickname: String): Boolean {
        if (blackNickname.isBlank() || blackNickname.length !in 2..10) {
            return false
        }
        if (whiteNickname.isBlank() || whiteNickname.length !in 2..10) {
            return false
        }
        return getPrefs(context).edit()
            .putString(KEY_BLACK_NICKNAME, blackNickname.trim())
            .putString(KEY_WHITE_NICKNAME, whiteNickname.trim())
            .commit()
    }

    fun hasPvpNicknames(context: Context): Boolean {
        return !getBlackNickname(context).isNullOrEmpty()
            && !getWhiteNickname(context).isNullOrEmpty()
    }

    fun clearPvpNicknames(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_BLACK_NICKNAME)
            .remove(KEY_WHITE_NICKNAME)
            .apply()
    }
}
