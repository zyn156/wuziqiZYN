package com.system.wuziqi.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("ai_game_record")
public class AiGameRecord {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String playerName;

    private Integer pieceType;

    private Integer winCount;

    private Integer loseCount;

    private Integer totalCount;

    private Double winRate;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
