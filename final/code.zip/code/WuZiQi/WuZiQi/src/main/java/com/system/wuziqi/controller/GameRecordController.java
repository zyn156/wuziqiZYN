package com.system.wuziqi.controller;

import com.system.wuziqi.dto.RankingResponse;
import com.system.wuziqi.dto.RecordGameRequest;
import com.system.wuziqi.service.GameRecordService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/game")
@RequiredArgsConstructor
public class GameRecordController {

    private final GameRecordService gameRecordService;

    @PostMapping("/recordGame")
    public Map<String, Object> recordGame(@RequestBody RecordGameRequest request) {
        Map<String, Object> result = new HashMap<>();
        try {
            gameRecordService.recordGame(request.getGameType(), request.getPlayerName(),
                    request.getPieceType(), request.getGameResult());
            result.put("code", 200);
            result.put("msg", "记录成功");
            result.put("data", null);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", "记录失败: " + e.getMessage());
            result.put("data", null);
        }
        return result;
    }

    @GetMapping("/ranking")
    public Map<String, Object> getRanking(@RequestParam Integer gameType, @RequestParam Integer pieceType) {
        Map<String, Object> result = new HashMap<>();
        try {
            List<RankingResponse> rankingList = gameRecordService.getRanking(gameType, pieceType);
            result.put("code", 200);
            result.put("msg", "查询成功");
            result.put("data", rankingList);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("msg", "查询失败: " + e.getMessage());
            result.put("data", null);
        }
        return result;
    }
}
