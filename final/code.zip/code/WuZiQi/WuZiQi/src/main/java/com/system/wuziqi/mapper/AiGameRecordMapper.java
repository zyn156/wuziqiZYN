package com.system.wuziqi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.system.wuziqi.entity.AiGameRecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AiGameRecordMapper extends BaseMapper<AiGameRecord> {
}
