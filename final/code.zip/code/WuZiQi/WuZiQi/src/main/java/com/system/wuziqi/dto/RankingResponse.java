package com.system.wuziqi.dto;

import lombok.Data;

@Data
public class RankingResponse {
    private Integer rank;
    private String playerName;
    private Integer pieceType;
    private Integer winCount;
    private Integer loseCount;
    private Integer totalCount;
    private Double winRate;
}
