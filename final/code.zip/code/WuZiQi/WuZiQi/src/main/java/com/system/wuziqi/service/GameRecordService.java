package com.system.wuziqi.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.system.wuziqi.dto.RankingResponse;
import com.system.wuziqi.entity.AiGameRecord;
import com.system.wuziqi.entity.LocalGameRecord;
import com.system.wuziqi.mapper.AiGameRecordMapper;
import com.system.wuziqi.mapper.LocalGameRecordMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
public class GameRecordService {

    private final AiGameRecordMapper aiGameRecordMapper;
    private final LocalGameRecordMapper localGameRecordMapper;

    @Transactional(rollbackFor = Exception.class)
    public void recordGame(Integer gameType, String playerName, Integer pieceType, Integer gameResult) {
        if (gameType == 1) {
            recordAiGame(playerName, pieceType, gameResult);
        } else if (gameType == 2) {
            recordLocalGame(playerName, pieceType, gameResult);
        }
    }

    private void recordAiGame(String playerName, Integer pieceType, Integer gameResult) {
        LambdaQueryWrapper<AiGameRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AiGameRecord::getPlayerName, playerName)
                .eq(AiGameRecord::getPieceType, pieceType);
        AiGameRecord record = aiGameRecordMapper.selectOne(queryWrapper);

        if (record == null) {
            // 没有记录就新建一个
            record = new AiGameRecord();
            record.setPlayerName(playerName);
            record.setPieceType(pieceType);
            record.setWinCount(gameResult == 1 ? 1 : 0);
            record.setLoseCount(gameResult == 2 ? 1 : 0);
            record.setTotalCount(1);
            record.setWinRate(gameResult == 1 ? 100.0 : 0.0);
            aiGameRecordMapper.insert(record);
        } else {
            // 有记录就更新，直接用SQL算胜率
            String sql = gameResult == 1
                ? "win_count = win_count + 1, total_count = total_count + 1, win_rate = ROUND((win_count + 1) * 100.0 / (total_count + 1), 2)"
                : "lose_count = lose_count + 1, total_count = total_count + 1, win_rate = ROUND(win_count * 100.0 / (total_count + 1), 2)";

            LambdaUpdateWrapper<AiGameRecord> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(AiGameRecord::getPlayerName, playerName)
                    .eq(AiGameRecord::getPieceType, pieceType)
                    .setSql(sql);
            aiGameRecordMapper.update(null, updateWrapper);
        }
    }

    private void recordLocalGame(String playerName, Integer pieceType, Integer gameResult) {
        LambdaQueryWrapper<LocalGameRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(LocalGameRecord::getPlayerName, playerName)
                .eq(LocalGameRecord::getPieceType, pieceType);
        LocalGameRecord record = localGameRecordMapper.selectOne(queryWrapper);

        if (record == null) {
            // 没有记录就新建一个
            record = new LocalGameRecord();
            record.setPlayerName(playerName);
            record.setPieceType(pieceType);
            record.setWinCount(gameResult == 1 ? 1 : 0);
            record.setLoseCount(gameResult == 2 ? 1 : 0);
            record.setTotalCount(1);
            record.setWinRate(gameResult == 1 ? 100.0 : 0.0);
            localGameRecordMapper.insert(record);
        } else {
            // 有记录就更新，直接用SQL算胜率
            String sql = gameResult == 1
                ? "win_count = win_count + 1, total_count = total_count + 1, win_rate = ROUND((win_count + 1) * 100.0 / (total_count + 1), 2)"
                : "lose_count = lose_count + 1, total_count = total_count + 1, win_rate = ROUND(win_count * 100.0 / (total_count + 1), 2)";

            LambdaUpdateWrapper<LocalGameRecord> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(LocalGameRecord::getPlayerName, playerName)
                    .eq(LocalGameRecord::getPieceType, pieceType)
                    .setSql(sql);
            localGameRecordMapper.update(null, updateWrapper);
        }
    }

    public List<RankingResponse> getRanking(Integer gameType, Integer pieceType) {
        List<RankingResponse> rankingList = new ArrayList<>();

        if (gameType == 1) {
            // 人机排行榜，按胜率排序
            LambdaQueryWrapper<AiGameRecord> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(AiGameRecord::getPieceType, pieceType)
                    .orderByDesc(AiGameRecord::getWinRate)
                    .orderByDesc(AiGameRecord::getWinCount)
                    .orderByAsc(AiGameRecord::getCreateTime);
            List<AiGameRecord> records = aiGameRecordMapper.selectList(queryWrapper);

            AtomicInteger rank = new AtomicInteger(1);
            records.forEach(record -> {
                RankingResponse response = new RankingResponse();
                response.setRank(rank.getAndIncrement());
                response.setPlayerName(record.getPlayerName());
                response.setPieceType(record.getPieceType());
                response.setWinCount(record.getWinCount());
                response.setLoseCount(record.getLoseCount());
                response.setTotalCount(record.getTotalCount());
                response.setWinRate(record.getWinRate());
                rankingList.add(response);
            });
        } else if (gameType == 2) {
            // 本地排行榜，按胜率排序
            LambdaQueryWrapper<LocalGameRecord> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(LocalGameRecord::getPieceType, pieceType)
                    .orderByDesc(LocalGameRecord::getWinRate)
                    .orderByDesc(LocalGameRecord::getWinCount)
                    .orderByAsc(LocalGameRecord::getCreateTime);
            List<LocalGameRecord> records = localGameRecordMapper.selectList(queryWrapper);

            AtomicInteger rank = new AtomicInteger(1);
            records.forEach(record -> {
                RankingResponse response = new RankingResponse();
                response.setRank(rank.getAndIncrement());
                response.setPlayerName(record.getPlayerName());
                response.setPieceType(record.getPieceType());
                response.setWinCount(record.getWinCount());
                response.setLoseCount(record.getLoseCount());
                response.setTotalCount(record.getTotalCount());
                response.setWinRate(record.getWinRate());
                rankingList.add(response);
            });
        }

        return rankingList;
    }
}
