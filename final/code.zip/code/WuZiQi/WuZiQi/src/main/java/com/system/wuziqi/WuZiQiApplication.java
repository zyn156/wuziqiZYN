package com.system.wuziqi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WuZiQiApplication {

    public static void main(String[] args) {
        SpringApplication.run(WuZiQiApplication.class, args);
    }

}
