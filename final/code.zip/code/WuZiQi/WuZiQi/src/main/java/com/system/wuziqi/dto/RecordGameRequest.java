package com.system.wuziqi.dto;

import lombok.Data;

@Data
public class RecordGameRequest {
    private Integer gameType;
    private String playerName;
    private Integer pieceType;
    private Integer gameResult;
}
