package com.system.wuziqi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WuZiQiApplicationTests {

    @Test
    void contextLoads() {
    }

}
