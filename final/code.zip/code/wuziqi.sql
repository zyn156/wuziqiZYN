-- 创建数据库
CREATE DATABASE IF NOT EXISTS `wuziqi_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `wuziqi_db`;

-- 人机对战胜利记录表
CREATE TABLE `ai_game_record` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `player_name` VARCHAR(50) NOT NULL COMMENT '玩家名称',
  `piece_type` TINYINT NOT NULL COMMENT '棋子类型 1:黑棋 2:白棋',
  `win_count` INT NOT NULL DEFAULT 0 COMMENT '胜利次数',
  `lose_count` INT NOT NULL DEFAULT 0 COMMENT '失败次数',
  `total_count` INT NOT NULL DEFAULT 0 COMMENT '总场次',
  `win_rate` DECIMAL(5,2) NOT NULL DEFAULT 0.00 COMMENT '胜率(百分比,如:75.50表示75.50%)',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_player_piece` (`player_name`, `piece_type`) COMMENT '玩家+棋子类型唯一索引',
  KEY `idx_win_rate` (`piece_type`, `win_rate` DESC) COMMENT '胜率排序索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='人机对战胜利记录表';

-- 本地对战胜利记录表
CREATE TABLE `local_game_record` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `player_name` VARCHAR(50) NOT NULL COMMENT '玩家名称',
  `piece_type` TINYINT NOT NULL COMMENT '棋子类型 1:黑棋 2:白棋',
  `win_count` INT NOT NULL DEFAULT 0 COMMENT '胜利次数',
  `lose_count` INT NOT NULL DEFAULT 0 COMMENT '失败次数',
  `total_count` INT NOT NULL DEFAULT 0 COMMENT '总场次',
  `win_rate` DECIMAL(5,2) NOT NULL DEFAULT 0.00 COMMENT '胜率(百分比,如:75.50表示75.50%)',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_player_piece` (`player_name`, `piece_type`) COMMENT '玩家+棋子类型唯一索引',
  KEY `idx_win_rate` (`piece_type`, `win_rate` DESC) COMMENT '胜率排序索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='本地对战胜利记录表';
